#ifndef _LGE_ATS_CMD_H_
#define _LGE_ATS_CMD_H_

extern int external_memory_test(void);

#endif /*_LGE_ATS_CMD_H_*/
